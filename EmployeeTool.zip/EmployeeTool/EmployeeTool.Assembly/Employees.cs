﻿using System;
using System.Collections.Generic;
using System.IO;

namespace EmployeeTool.Assembly
{
    /// <summary>
    /// Employees Class
    /// </summary>
    public class Employees
    {
        List<Employee> employeesList = new List<Employee>();
        /// <summary>
        /// Constructor which takes csv file as argument and process the data for adding it to the collection
        /// </summary>
        /// <param name="strPath"></param>
        public Employees(string strPath)
        {

            if (!string.IsNullOrEmpty(strPath))
            {
                if (File.Exists(strPath))
                {
                    string[] lines = File.ReadAllLines(strPath);
                    foreach (string line in lines)
                    {
                        Employee emp = new Employee();
                        int sal = 0;
                        string[] properties = line.Split(',');
                        int.TryParse(properties[2], out sal);
                        if (sal != 0)
                        {
                            if (employeesList.Count > 0)
                            {
                                if (employeesList.FindAll(e => e.employeeId == properties[0]).Count < 1)
                                {
                                    if (!string.IsNullOrEmpty(properties[1]))
                                    {
                                        if (!DoubleManagerCheck(properties[0]) && !IsCircularReference(properties[0], properties[1]))
                                            employeesList.Add(new Employee { employeeId = properties[0].Trim(), managerId = properties[1].Trim(), salary = sal });
                                    }
                                    else
                                    {
                                        if (!employeesList.Exists(e => string.IsNullOrEmpty(e.managerId)))
                                        {
                                            employeesList.Add(new Employee { employeeId = properties[0].Trim(), salary = sal });
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Can not add duplicate details of employee " + properties[0] + " !");
                                }
                            }
                            else
                            {
                                employeesList.Add(new Employee { employeeId = properties[0].Trim(), managerId = properties[1].Trim(), salary = sal });
                            }
                        }
                        else
                        {
                            Console.WriteLine("Salary should be an integer value !");
                        }
                    }
                    RemoveManagerWhoIsNotEmp();
                }
                else
                {
                    Console.WriteLine("File " + strPath + " does not exist!");
                }
            }
            else
            {
                Console.WriteLine("Please enter the csv file path!");
            }
        }
        /// <summary>
        /// Function/Method to check for the Circular Reference in Reporting Manager
        /// </summary>
        /// <param name="employeeId"></param>
        /// <param name="managerId"></param>
        /// <returns></returns>
        bool IsCircularReference(string employeeId, string managerId)
        {
            bool isCircularRef = false;
            string empId = string.Empty;
            foreach (Employee emp in employeesList)
            {
                if (emp.managerId == employeeId)
                {
                    empId = emp.employeeId;
                    break;
                }
            }
            foreach (Employee emp in employeesList)
            {
                if (emp.managerId == empId)
                {
                    if (emp.employeeId == managerId)
                    {
                        isCircularRef = true;
                        Console.WriteLine("Cyclic Reference occurred, hence skipping this record...");
                    }
                }
            }
            if (isCircularRef)
                employeesList.RemoveAll(e => e.employeeId == empId);
            return isCircularRef;
        }

        /// <summary>
        /// Function/Method to check whether employee is having multiple managers
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        bool DoubleManagerCheck(string employeeId)
        {
            bool isDoubleLink = false;
            string managerId = string.Empty;
            foreach (Employee emp in employeesList)
            {
                if (emp.employeeId == employeeId)
                {
                    if (string.IsNullOrEmpty(managerId))
                    {
                        managerId = emp.managerId;
                    }
                    else
                    {
                        if (managerId != emp.managerId)
                        {
                            isDoubleLink = true;
                            Console.WriteLine("Employee with multiple managers is not allowed, hence skipping this record!");
                            break;
                        }
                    }
                }
            }
            return isDoubleLink;
        }
        /// <summary>
        /// For displaying Employee details read from the csv
        /// </summary>
        /// <returns></returns>
        public List<Employee> ShowEmployees()
        {
            return employeesList;
        }
        /// <summary>
        /// Function/Method for salary budget
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        public int GetSalaryBudget(string employeeId)
        {
            int sal = 0;
            foreach (Employee emp in employeesList)
            {
                if (emp.employeeId == employeeId)
                {
                    sal += emp.salary;
                    sal += GetManager(emp.employeeId);
                }
            }
            return sal;
        }

        /// <summary>
        /// Recursive function/method for salary calculation
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        int GetManager(string employeeId)
        {
            int sal = 0;
            foreach (Employee emp in employeesList)
            {
                if (emp.managerId == employeeId)
                {
                    sal += emp.salary;
                    sal += GetManager(emp.employeeId);
                }
            }
            return sal;
        }
        /// <summary>
        /// Function/Method to remove Employees having Managers [who themselves are not employees]
        /// </summary>
        void RemoveManagerWhoIsNotEmp()
        {
            string managerIds = "";

            foreach (Employee emp in employeesList)
            {
                bool found = false;
                foreach (Employee emp1 in employeesList)
                {
                    if (emp1.employeeId == emp.managerId)
                    {
                        found = true;
                        break;
                    }
                }
                if (!found)
                {
                    managerIds += emp.managerId + ",";
                }
            }
            string[] separator = { "," };
            string[] managers = managerIds.Split(separator, StringSplitOptions.RemoveEmptyEntries);
            foreach (string manager in managers)
            {
                employeesList.RemoveAll(e => manager == e.managerId);
            }
        }
    }

    /// <summary>
    /// Employee Class
    /// </summary>
    public class Employee
    {
        public string employeeId { get; set; }
        public string managerId { get; set; }
        public int salary { get; set; }
    }
}

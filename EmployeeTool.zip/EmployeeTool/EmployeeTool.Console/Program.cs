﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeTool.Assembly;
namespace EmployeeTool.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            string solution_dir = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
            string parentDir = Directory.GetParent(solution_dir).Parent.Parent.FullName.Replace("\\bin\\Debug", string.Empty);

            System.Console.WriteLine("Choose from the following:");
            System.Console.WriteLine("1 for csv with all valid inputs");
            System.Console.WriteLine("2 for Double Manager Link Check");
            System.Console.WriteLine("3 for Circular Reference Check");
            System.Console.WriteLine("4 for Check whether Salary is an integer");
            System.Console.WriteLine("5 for Check for having single CEO");
            System.Console.WriteLine("6 for Check for Salary Budget");
            System.Console.WriteLine("7 for manually entering csv path");
            int choice = 0;
            int.TryParse(System.Console.ReadLine(), out choice);
            string strPath = "";
            switch (choice)
            {
                case 1:
                    strPath = parentDir + "\\csv\\Employees.csv";
                    break;
                case 2:
                    strPath = parentDir + "\\csv\\EmployeesDoub.csv";
                    break;
                case 3:
                    strPath = parentDir + "\\csv\\EmployeesCir.csv";
                    break;
                case 4:
                    strPath = parentDir + "\\csv\\EmployeesS.csv";
                    break;
                case 5:
                    strPath = parentDir + "\\csv\\EmployeesC.csv";
                    break;
                case 6:
                    strPath = parentDir + "\\csv\\EmployeesB.csv";
                    break;
                case 7:
                    System.Console.Write("Enter csv file path:");
                    strPath = System.Console.ReadLine();
                    break;
                default:
                    strPath = parentDir + "\\csv\\Employees.csv";
                    break;
            }
            if (!string.IsNullOrEmpty(strPath))
            {
                // For reading and validating data from the csv file
                Employees objEmployees = new Employees(strPath);

                // For displaying the read/clean data after validation
                List<Employee> empList = objEmployees.ShowEmployees();
                foreach (Employee emp in empList)
                {
                    System.Console.WriteLine(emp.employeeId + ", " + emp.managerId + ", " + emp.salary);
                }
                #region For 2b
                System.Console.Write("Enter employeeid for salary calculation: ");
                string empId = System.Console.ReadLine();

                System.Console.WriteLine("Total Salary of " + empId + " Result: " + objEmployees.GetSalaryBudget(empId));
                #endregion
            }
            else
            {
                System.Console.WriteLine("Please enter valid csv file path!");
            }
            System.Console.WriteLine("Press any key to exit.");
            System.Console.ReadKey();
        }
    }
}

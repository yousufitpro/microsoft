﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using EmployeeTool.Assembly;
using System.IO;

namespace EmployeeTool.UnitTests
{
    [TestClass]
    public class SalaryTest
    {
       static string solution_dir = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
        string parentDir = Directory.GetParent(solution_dir).Parent.FullName.Replace("bin\\Debug", string.Empty);
        [TestMethod]
        public void CheckSalaryBudget()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmployeesB.csv");
            Assert.AreEqual(1800, objEmployees.GetSalaryBudget("Employee2"));
            Assert.AreEqual(500, objEmployees.GetSalaryBudget("Employee3"));
            Assert.AreEqual(3800, objEmployees.GetSalaryBudget("Employee1"));
        }

        [TestMethod]
        public void CheckSalary()
        {
            Employees objEmployees = new Employees(parentDir +"\\EmployeesS.csv");
            Assert.AreEqual(1800, objEmployees.GetSalaryBudget("Employee2"));
        }

        [TestMethod]
        public void CheckMultipleManager()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmployeesDoub.csv");
            Assert.AreEqual(500, objEmployees.GetSalaryBudget("Employee4"));
            Assert.AreEqual(500, objEmployees.GetSalaryBudget("Employee3"));
        }

        [TestMethod]
        public void CheckOnlyOneCEO()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmployeesC.csv");
            Assert.AreEqual(3800, objEmployees.GetSalaryBudget("Employee1"));
            Assert.AreEqual(0, objEmployees.GetSalaryBudget("Employee7"));
        }

        [TestMethod]
        public void CheckCircularReference()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmployeesCir.csv");
            Assert.AreEqual(0, objEmployees.GetSalaryBudget("Employee2"));
            Assert.AreEqual(0, objEmployees.GetSalaryBudget("Employee3"));
            Assert.AreEqual(0, objEmployees.GetSalaryBudget("Employee4"));
        }

        [TestMethod]
        public void CheckManagerWhoIsNotEmployee()
        {
            Employees objEmployees = new Employees(parentDir + "\\EmployeesCir.csv");
            Assert.AreEqual(1500, objEmployees.GetSalaryBudget("Employee1"));
            Assert.AreEqual(500, objEmployees.GetSalaryBudget("Employee5"));
            Assert.AreEqual(0, objEmployees.GetSalaryBudget("Employee4"));
        }
    }
}

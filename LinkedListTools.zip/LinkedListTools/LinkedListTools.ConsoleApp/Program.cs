﻿using LinkedListTools.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LinkedListTools.ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Please enter LinkedList Nodes without spaces(A to Z): ");
            string inputString = Console.ReadLine();

            if (!string.IsNullOrEmpty(inputString))
            {
                foreach (char item in inputString.ToCharArray())
                {
                    LinkedListHelpers.AddNode(item);
                }
                Console.WriteLine("\n\nNodes in the LinkedList are..... ");
                LinkedListHelpers.PrintList();
                LinkedListHelpers.RemoveDuplicateNodes(LinkedListHelpers.root);
                Console.WriteLine("\n\nNodes after removing duplicates (reapeated more than twice)....");
                LinkedListHelpers.PrintList();
            }
            else
            {
                Console.WriteLine("\nPlease enter Linked List Items!");
            }
            Console.ReadKey();
        }
    }
}

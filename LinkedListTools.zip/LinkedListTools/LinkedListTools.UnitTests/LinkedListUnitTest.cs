﻿using System;
using LinkedListTools.Helpers;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace LinkedListTools.UnitTests
{
    [TestClass]
    public class LinkedListUnitTest
    {
        [TestMethod]
        public void TestAddNode()
        {
            LinkedListHelpers.AddNode('B');
            Assert.IsTrue(LinkedListHelpers.root.data.Equals('B'));
            Assert.AreEqual(null,LinkedListHelpers.root.next);
            LinkedListHelpers.AddNode('C');
            Assert.IsTrue(LinkedListHelpers.root.next.data.Equals('C'));
            Assert.AreEqual(null, LinkedListHelpers.root.next.next);
        }

        [TestMethod]
        public void TestRemoveDuplicateNodes()
        {
            string inputString = "EBEEBAB";
            foreach(char nodeValue in inputString.ToCharArray())
            {
                LinkedListHelpers.AddNode(nodeValue);
            }
            LinkedListHelpers.RemoveDuplicateNodes(LinkedListHelpers.root);

            Assert.IsTrue(LinkedListHelpers.root.data.Equals('E'));
            Assert.IsTrue(LinkedListHelpers.root.next.data.Equals('B'));
            Assert.IsTrue(LinkedListHelpers.root.next.next.data.Equals('E'));
            Assert.IsTrue(LinkedListHelpers.root.next.next.next.data.Equals('B'));
            Assert.IsTrue(LinkedListHelpers.root.next.next.next.next.data.Equals('A'));
            Assert.AreEqual(null, LinkedListHelpers.root.next.next.next.next.next);

        }


    }
}

﻿using System;

namespace LinkedListTools.Helpers
{
    public class Node
    {
        public char data;
        public Node next;
        /// <summary>
        /// Node Constructor that takes root node value as parameter.
        /// </summary>
        /// <param name="d"></param>
        public Node(char d)
        {
            data = d;
            next = null;
        }

        /// <summary>
        /// For displaying Nodes in the LinkedList on the Console
        /// </summary>
        public void Print()
        {
            if(next != null)
            {
                Console.Write(data + "->");
                next.Print();
            }else
            {
                Console.Write(data );
            }
        }

        /// <summary>
        /// For adding a new Node to the LinkedList
        /// </summary>
        /// <param name="data"></param>
        public void Add(char data)
        {
            if(next == null)
            {
                next = new Node(data);
            }else
            {
                next.Add(data);
            }
        }
    }
}

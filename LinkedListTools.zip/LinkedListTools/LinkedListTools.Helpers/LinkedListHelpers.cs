﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LinkedListTools.Helpers
{
    public static class LinkedListHelpers
    {
        /// <summary>
        /// Root Node of the LinkedList
        /// </summary>
        public static Node root = null;

        /// <summary>
        /// For adding new Node to the LinkedList
        /// </summary>
        /// <param name="data"></param>
        public static void AddNode(char data)
        {
            if(root == null)
            {
                root = new Node(data);
            }
            else
            {
                root.Add(data);
            }
        }

        /// <summary>
        /// For displaying the Nodes of the LinkedList
        /// </summary>
        public static void PrintList()
        {
            if(root != null)
            {
                root.Print();
            }
        }

        /// <summary>
        /// For removing the duplicate Nodes (repeated more than twice) from the LinkedList 
        /// </summary>
        /// <param name="root"></param>
        public static void RemoveDuplicateNodes(Node root)
        {
            var count = 0;
            while(root != null && root.next != null)
            {
                Node current = root;
                while(current.next != null)
                {
                    // Counting the number of times the Node repeated
                    if (current.next.data == root.data)
                    {
                        count++;
                    }

                    // For removing the Node that repeated more than twice
                    if(count >= 2)
                    {
                        if(current.next.next != null)
                        {
                            current.next = current.next.next;
                        }
                        else
                        {
                            // In case, the repeated node is the last node in the LinkedList, next of current node should be assigned to null
                            current.next = null;
                        }
                        count = 0;
                    }
                    if(current.next != null)
                    {
                        current = current.next;
                    }
                }
                root = root.next;
            }
        }
    }
}
